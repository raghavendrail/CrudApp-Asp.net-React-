import React, { useState } from 'react';
import axios from 'axios';

function UserForm() {
    const [formData, setFormData] = useState({
        id: '', 
        name: '',
        address: '',
        state: '',
        district: '',
        dob: '', 
        language: ''
    });

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData({ ...formData, [name]: value });
    };

    const handleSubmit = (e) => {
        e.preventDefault();
       
        const formattedData = {
            ...formData,
        };

        axios.post('https://localhost:7071/api/User', formattedData)
            .then((response) => {
                alert('User data submitted successfully');
                setFormData({ id: '', name: '', address: '', state: '', district: '', dob: '', language: '' });
            })
            .catch((error) => {
                console.error('Error submitting data', error);
            });
    };

    return (
        <form onSubmit={handleSubmit}>
            <div>
                <label>ID: </label>
                <input
                    type="text"
                    name="id"
                    value={formData.id}
                    onChange={handleChange}
                    required
                />
            </div>
            <div>
                <label>Name: </label>
                <input type="text" name="name" value={formData.name} onChange={handleChange} required />
            </div>
            <div>
                <label>Address: </label>
                <input type="text" name="address" value={formData.address} onChange={handleChange} required />
            </div>
            <div>
                <label>State: </label>
                <select name="state" value={formData.state} onChange={handleChange} required>
                    <option value="">Select State</option>
                    <option value="Karnataka">Karnataka</option>
                    <option value="Maharashtra">Maharashtra</option>
                </select>
            </div>
            <div>
                <label>District: </label>
                <select name="district" value={formData.district} onChange={handleChange} required>
                    <option value="">Select District</option>
                    <option value="Bangalore">Bangalore</option>
                    <option value="Pune">Pune</option>
                </select>
            </div>
            <div>
                <label>Date of Birth: </label>
                <input
                    type="date"
                    name="dob"
                    value={formData.dob}
                    onChange={handleChange}
                    required
                />
            </div>
            <div>
                <label>Language: </label>
                <div>
                    <input type="radio" name="language" value="Kannada" onChange={handleChange} required /> Kannada
                    <input type="radio" name="language" value="Hindi" onChange={handleChange} required /> Hindi
                    <input type="radio" name="language" value="English" onChange={handleChange} required /> English
                </div>
            </div>
            <button type="submit">Submit</button>
        </form>
    );
}

export default UserForm;
