// UserManagement.js
import React, { useState } from 'react';
import UserForm from './UserForm';
import UserTable from './UserTable';

const UserManagement = () => {
    const [usersChanged, setUsersChanged] = useState(false);

    return (
        <div>
            <h1>User Management</h1>
            <UserForm onSubmit={() => setUsersChanged(!usersChanged)} />
            <UserTable />
        </div>
    );
};

export default UserManagement;
