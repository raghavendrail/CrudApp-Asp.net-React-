import React from 'react';
import UserForm from './components/UserForm';
import UserTable from './components/UserTable';

function App() {
    return (
        <div className="App">
            <h1>My CRUD App</h1>
            <UserForm />
            <UserTable />
        </div>
    );
}

export default App;
