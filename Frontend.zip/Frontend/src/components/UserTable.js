import React, { useEffect, useState } from 'react';
import axios from 'axios';

function UserTable() {
    const [users, setUsers] = useState([]);
    const [editingUser, setEditingUser] = useState(null);

    useEffect(() => {
        fetchUsers();
    }, []);

    const fetchUsers = () => {
        axios.get('https://localhost:7071/api/User')
            .then((response) => {
              
                const formattedUsers = response.data.map((user) => {
                    const dob = user.dateOfBirth && user.dateOfBirth !== '0001-01-01T00:00:00' 
                        ? user.dateOfBirth.split('T')[0] 
                        : ''; 

                    return { ...user, dob };
                });
                setUsers(formattedUsers);
            })
            .catch((error) => {
                console.error('Error fetching users', error);
            });
    };

    const handleDelete = (id) => {
        axios.delete(`https://localhost:7071/api/User/${id}`)
            .then(() => {
                setUsers(users.filter((user) => user.id !== id));
            })
            .catch((error) => {
                console.error('Error deleting user', error);
            });
    };

    const handleEdit = (id) => {
        axios.get(`https://localhost:7071/api/User/${id}`)
            .then((response) => {
                const user = response.data;
                // Format the date for editing
                user.dob = user.dateOfBirth && user.dateOfBirth !== '0001-01-01T00:00:00'
                    ? user.dateOfBirth.split('T')[0]
                    : '';
                setEditingUser(user);
            })
            .catch((error) => {
                console.error('Error fetching user by ID', error);
            });
    };

    const handleUpdate = () => {
        axios.put(`https://localhost:7071/api/User/${editingUser.id}`, editingUser)
            .then(() => {
                fetchUsers();
                setEditingUser(null);
            })
            .catch((error) => {
                console.error('Error updating user', error);
            });
    };

    return (
        <div>
            <table border="1">
                <thead>
                    <tr>
                        <th style={{ width: '200px' }}>Name</th>
                        <th style={{ width: '250px' }}>Address</th>
                        <th style={{ width: '150px' }}>State</th>
                        <th style={{ width: '150px' }}>District</th>
                        <th style={{ width: '150px' }}>Date of Birth</th>
                        <th style={{ width: '150px' }}>Language</th>
                        <th style={{ width: '150px' }}>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    {users.map((user) => (
                        <tr key={user.id}>
                            <td>{user.name}</td>
                            <td>{user.address}</td>
                            <td>{user.state}</td>
                            <td>{user.district}</td>
                            <td>{user.dob ? user.dob : 'N/A'}</td> {/* Display 'N/A' if DOB is empty */}
                            <td>{user.language}</td>
                            <td>
                                <button onClick={() => handleEdit(user.id)}>Edit</button>
                                <button onClick={() => handleDelete(user.id)}>Delete</button>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
            {editingUser && (
                <div>
                    <h3>Edit User</h3>
                    <form
                        onSubmit={(e) => {
                            e.preventDefault();
                            handleUpdate();
                        }}
                    >
                        <div>
                            <label>Name: </label>
                            <input
                                type="text"
                                value={editingUser.name}
                                onChange={(e) => setEditingUser({ ...editingUser, name: e.target.value })}
                            />
                        </div>
                        <div>
                            <label>Address: </label>
                            <input
                                type="text"
                                value={editingUser.address}
                                onChange={(e) => setEditingUser({ ...editingUser, address: e.target.value })}
                            />
                        </div>
                        <div>
                            <label>State: </label>
                            <select
                                value={editingUser.state}
                                onChange={(e) => setEditingUser({ ...editingUser, state: e.target.value })}
                            >
                                <option value="">Select State</option>
                                <option value="Karnataka">Karnataka</option>
                                <option value="Maharashtra">Maharashtra</option>
                            </select>
                        </div>
                        <div>
                            <label>District: </label>
                            <select
                                value={editingUser.district}
                                onChange={(e) => setEditingUser({ ...editingUser, district: e.target.value })}
                            >
                                <option value="">Select District</option>
                                <option value="Bangalore">Bangalore</option>
                                <option value="Pune">Pune</option>
                            </select>
                        </div>
                        <div>
                            <label>Date of Birth: </label>
                            <input
                                type="date"
                                value={editingUser.dob}
                                onChange={(e) => setEditingUser({ ...editingUser, dob: e.target.value })}
                                style={{ width: '100%' }}
                            />
                        </div>
                        <div>
                            <label>Language: </label>
                            <div>
                                <input
                                    type="radio"
                                    name="language"
                                    value="Kannada"
                                    checked={editingUser.language === 'Kannada'}
                                    onChange={(e) => setEditingUser({ ...editingUser, language: e.target.value })}
                                />{' '}
                                Kannada
                                <input
                                    type="radio"
                                    name="language"
                                    value="Hindi"
                                    checked={editingUser.language === 'Hindi'}
                                    onChange={(e) => setEditingUser({ ...editingUser, language: e.target.value })}
                                />{' '}
                                Hindi
                                <input
                                    type="radio"
                                    name="language"
                                    value="English"
                                    checked={editingUser.language === 'English'}
                                    onChange={(e) => setEditingUser({ ...editingUser, language: e.target.value })}
                                />{' '}
                                English
                            </div>
                        </div>
                        <button type="submit">Update</button>
                        <button type="button" onClick={() => setEditingUser(null)}>
                            Cancel
                        </button>
                    </form>
                </div>
            )}
        </div>
    );
}

export default UserTable;
